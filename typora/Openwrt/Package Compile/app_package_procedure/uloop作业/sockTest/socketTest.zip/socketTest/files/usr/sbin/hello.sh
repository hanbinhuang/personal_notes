#! /bin/sh

echo "hello" > /tmp/hello.txt
