#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <string.h>
#include <linux/netlink.h>
#include <stdint.h>
#include <unistd.h>
#include <time.h>
#include <libubox/uloop.h>
#include <libubox/usock.h>
#include <libubox/utils.h>
#include <libubox/blobmsg.h>
#include <libubox/blobmsg_json.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <libubus.h>

#define NETLINK_TEST     30
#define MSG_LEN          125
#define MAX_PLOAD        125
#define TIME_RANGE       86400
#define UBUS_METHOD_NAME    "homework"

typedef struct _user_msg_info {
    struct nlmsghdr hdr;
    char  msg[MSG_LEN];
} user_msg_info;

int skfd;
static struct ubus_context* g_ubus_ctx;
struct sockaddr_nl saddr, daddr;
struct nlmsghdr *nlh = NULL;
user_msg_info u_info;
socklen_t len;

int seng_msg(char *data, int len)
{
    int ret = -1;
    memcpy(NLMSG_DATA(nlh), data, len);
    ret = sendto(skfd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&daddr, sizeof(struct sockaddr_nl));
    if(!ret) {
        printf("sendto error\n");
        close(skfd);
        exit(-1);
    }
    printf("send to kernel:%s\n", data);
    return ret;
}

void server_callback(struct uloop_fd *fd, unsigned int events)
{
    int ret = 0;
    long int rand_timeout;
     char umsg[100] = {0};

    /* 循环接收信息 */
    memset(&u_info, 0, sizeof(u_info));
    len = sizeof(struct sockaddr_nl);
    ret = recvfrom(skfd, &u_info, sizeof(user_msg_info), 0, (struct sockaddr *)&daddr, &len);
    if (!ret) {
        printf("recv form kernel error\n");
        close(skfd);
        exit(-1);
    }
    printf("receive from kernel:%s\n", u_info.msg);

    /* 收到内核发送的信息回复一个随机的未来时间 */
    if (u_info.msg) {
        time_t seconds = time(NULL); /* 获取当前时间戳 */
        rand_timeout = (long int)rand() % TIME_RANGE; /* 获取随机时间 */
        sprintf(umsg, "msg timeout_sec_rsp %s %ld msgend",u_info.msg, (long int)(seconds + rand_timeout)); /* 返回当前时间+随机时间 */
        seng_msg(umsg, strlen(umsg));
    }
}

struct uloop_fd server = {
    .cb = server_callback,
};

int main(int argc, char **argv)
{
    int ret;

    uloop_init();
    skfd = socket(AF_NETLINK, SOCK_RAW, NETLINK_TEST);
    if(skfd == -1) {
        printf("create socket error\n");
        return -1;
    }
    memset(&saddr, 0, sizeof(saddr));
    saddr.nl_family = AF_NETLINK; 
    saddr.nl_pid = 100; 
    saddr.nl_groups = 0;
    if (bind(skfd, (struct sockaddr *)&saddr, sizeof(saddr)) != 0) {
        perror("bind() error\n");
        close(skfd);
        return -1;
    }
    memset(&daddr, 0, sizeof(daddr));
    daddr.nl_family = AF_NETLINK;
    daddr.nl_pid = 0; 
    daddr.nl_groups = 0;

    nlh = (struct nlmsghdr *)malloc(NLMSG_SPACE(MAX_PLOAD));
    memset(nlh, 0, sizeof(struct nlmsghdr));
    nlh->nlmsg_len = NLMSG_SPACE(MAX_PLOAD);
    nlh->nlmsg_flags = 0;
    nlh->nlmsg_type = 0;
    nlh->nlmsg_seq = 0;
    nlh->nlmsg_pid = saddr.nl_pid; 
    server.fd = skfd;
    uloop_fd_add(&server, ULOOP_READ | ULOOP_EDGE_TRIGGER);
    ubus_init();
    uloop_run();
    uloop_done();
    close(skfd);
    free((void *)nlh);
    return 0;
}

/* ubus设置超时时间 */
enum {
    UBUS_TIMEOUT_KEY = 0,
    UBUS_TIMEOUT_VALUE,
    UBUS_TIMEOUT_MAX,
};

static const struct blobmsg_policy ubus_set_timeout_policy[UBUS_TIMEOUT_MAX] = {
    [UBUS_TIMEOUT_KEY] = { .name = "mac",   .type = BLOBMSG_TYPE_STRING },
    [UBUS_TIMEOUT_VALUE]  = { .name = "time",   .type = BLOBMSG_TYPE_INT32 },

};

static int ubus_set_timeout(struct ubus_context *ctx, struct ubus_object *obj,
    struct ubus_request_data *req, const char *method, struct blob_attr *msg)
{
  struct blob_attr *tb[UBUS_TIMEOUT_MAX];
    long int timeout = 0;
    char mac[13] = {0};
    struct blob_buf b;
    char tmp_buf[100] = {0};

    blobmsg_parse(ubus_set_timeout_policy, UBUS_TIMEOUT_MAX, tb,
                  blob_data(msg), blob_len(msg));

    if (tb[UBUS_TIMEOUT_KEY] && tb[UBUS_TIMEOUT_VALUE]) {
        strncpy(mac, blobmsg_data(tb[UBUS_TIMEOUT_KEY]), 12);
        timeout = blobmsg_get_u32(tb[UBUS_TIMEOUT_VALUE]);
    }
    
    memset(&b, 0, sizeof(struct blob_buf));
    blob_buf_init(&b, 0);
    blobmsg_add_string(&b, "mac", mac);
    blobmsg_add_u32(&b, "time", timeout);
    ubus_send_reply(ctx, req, b.head);
    blob_buf_free(&b);
    sprintf(tmp_buf, "msg ubus_set_sec %s %ld msgend ", mac, timeout);
    seng_msg(tmp_buf, strlen(tmp_buf));
    return 0;
}

/* ubus删除用户 */
enum {
    UBUS_DEL_USER_VALUE,
    UBUS_DEL_USER_MAX,
};

static const struct blobmsg_policy ubus_del_user_policy[UBUS_DEL_USER_MAX] = {
    [UBUS_DEL_USER_VALUE]  = { .name = "mac",   .type = BLOBMSG_TYPE_STRING },
};

static int ubus_del_user(struct ubus_context *ctx, struct ubus_object *obj,
    struct ubus_request_data *req, const char *method, struct blob_attr *msg)
{
    struct blob_attr *tb[UBUS_DEL_USER_MAX];
    char mac[13] = {0};
    char tmp_buf[100] = {0};
    struct blob_buf b;

    blobmsg_parse(ubus_del_user_policy, UBUS_DEL_USER_MAX, tb,
                  blob_data(msg), blob_len(msg));

    if (!tb[UBUS_DEL_USER_VALUE]) {
      return UBUS_STATUS_INVALID_ARGUMENT;
    }
    memcpy(mac, blobmsg_data(tb[UBUS_DEL_USER_VALUE]), 12);

    memset(&b, 0, sizeof(struct blob_buf));
    blob_buf_init(&b, 0);
    blobmsg_add_string(&b, "mac", mac);
    ubus_send_reply(ctx, req, b.head);
    blob_buf_free(&b);
    sprintf(tmp_buf, "msg ubus_del_user %s %ld msgend", mac, 0);
    seng_msg(tmp_buf, strlen(tmp_buf));
    return 0;
}

/* 设置最大用户数量 */
enum {
    UBUS_MAX_USER_VALUE,
    UBUS_MAX_USER_MAX,
};

static const struct blobmsg_policy ubus_set_max_user_policy[UBUS_MAX_USER_MAX] = {
    [UBUS_MAX_USER_VALUE]  = { .name = "num", .type = BLOBMSG_TYPE_INT32 },
};

static int ubus_set_max_user(struct ubus_context *ctx, struct ubus_object *obj,
    struct ubus_request_data *req, const char *method, struct blob_attr *msg)
{
    struct blob_attr *tb[UBUS_MAX_USER_MAX];
    char tmp_buf[100] = {0};
    struct blob_buf b;
    long int number = 0;

    blobmsg_parse(ubus_set_max_user_policy, UBUS_MAX_USER_MAX, tb,
                  blob_data(msg), blob_len(msg));

    if (!tb[UBUS_MAX_USER_VALUE]) {
      return UBUS_STATUS_INVALID_ARGUMENT;
    }
    number = blobmsg_get_u32(tb[UBUS_MAX_USER_VALUE]);

    memset(&b, 0, sizeof(struct blob_buf));
    blob_buf_init(&b, 0);
    blobmsg_add_u32(&b, "num", number);
    ubus_send_reply(ctx, req, b.head);
    blob_buf_free(&b);
    sprintf(tmp_buf, "msg ubus_set_maxuser %s %ld msgend", "FFFFFFFFFFFF", number);
    seng_msg(tmp_buf, strlen(tmp_buf));
    return 0;
}

static int ubus_show_user(struct ubus_context *ctx, struct ubus_object *obj,
    struct ubus_request_data *req, const char *method, struct blob_attr *msg)
{
    char tmp_buf[100] = {0};
    sprintf(tmp_buf, "msg ubus_show_user %s %ld msgend", "FFFFFFFFFFFF", 0);
    seng_msg(tmp_buf, strlen(tmp_buf));
    return 0;
}

static const struct ubus_method ubus_methods[] = {
    UBUS_METHOD("set_timeout", ubus_set_timeout, ubus_set_timeout_policy),
    UBUS_METHOD("del_user", ubus_del_user, ubus_del_user_policy),
    UBUS_METHOD("set_max_user", ubus_set_max_user, ubus_set_max_user_policy),
    UBUS_METHOD_NOARG("show_user", ubus_show_user),
};

static struct ubus_object_type ubus_obj_type =
    UBUS_OBJECT_TYPE(UBUS_METHOD_NAME, ubus_methods);

static struct ubus_object ubus_apmgr_obj = {
    .name = UBUS_METHOD_NAME,
    .type = &ubus_obj_type,
    .methods = ubus_methods,
    .n_methods = ARRAY_SIZE(ubus_methods),
};

static void ubus_reconnect_timer(struct uloop_timeout *timeout)
{
    static struct uloop_timeout retry = {
        .cb = ubus_reconnect_timer,
    };

    if (ubus_reconnect(g_ubus_ctx, NULL) != 0) {
        uloop_timeout_set(&retry, 3000);
        return;
    }

    ubus_add_uloop(g_ubus_ctx);

    return;
}

static void ubus_connection_lost(struct ubus_context *ctx)
{
    (void)ubus_reconnect_timer(NULL);

    return;
}

int ubus_init(void)
{
    g_ubus_ctx = ubus_connect(NULL);
    if (g_ubus_ctx == NULL) {
        printf("Failed to connect to ubus!\n");
        return -1;
    }
    g_ubus_ctx->connection_lost = &ubus_connection_lost;
    ubus_add_uloop(g_ubus_ctx);

    if (ubus_add_object(g_ubus_ctx, &ubus_apmgr_obj) != 0) {
        printf("Failed to add obj ubus_apmgr_obj\n");
        return -1;
    }

    return 0;
}

