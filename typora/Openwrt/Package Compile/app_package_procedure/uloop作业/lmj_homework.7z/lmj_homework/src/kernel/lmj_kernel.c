/*
 * Copyright(C) 2021 Ruijie Network. All rights reserved.
 *
 * demo.c
 * Original Author:  liminjie@ruijie.com.cn, 2022-09-06
 *
 * History
 *
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/timer.h>
#include <linux/jiffies.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <net/sock.h>
#include <linux/netlink.h>
#include<linux/slab.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/moduleparam.h>
#include <linux/time.h>
#include <linux/proc_fs.h>  
#include <asm/uaccess.h>  
#include <linux/kernel.h>  
#include <linux/module.h>  
#include <linux/kernel.h>  
#include <linux/init.h>  
#include <linux/proc_fs.h>  
#include <linux/jiffies.h>  
#include <asm/uaccess.h>  
  
#define NETLINK_TEST     30
#define USER_PORT        100
#define MAC_ADDR_LENGTH  12
#define MAC_HASH_SIZE    256
#define MAX_USER_NUM     65536
#define FOOBAR_LEN 8  
#define PROC_NODE_ROOT_NAME	"proc_test"

/* 内核与用户空间通信消息类型 */
typedef enum msg_type_s{
    TIMEOUT_SEC_RSP = 0,
    UBUS_DEL_USER,
    UBUS_SET_TIMEOUT_SEC,
    UBUS_SET_MAX_USER,
    UBUS_SHOW_USER,
}msg_type_t;

/* 哈希表 */
typedef struct mac_hlsit_s{
    char mac[20];
    long int timeout_sec;
    struct hlist_node list;
}mac_hlsit_t;

/* 系统信息 */
typedef struct mysysinfo_s{
    long int max_user_num;
    int current_user_num;
}mysysinfo_t;

mysysinfo_t mysysinfo;
unsigned char HEXCHAR[16]={'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
struct sock *nlsk = NULL;
extern struct net init_net;
unsigned char genMACAddr[MAC_ADDR_LENGTH] = {0};
struct timer_list timer, timer2; 
struct hlist_head mac_hlist[MAC_HASH_SIZE];
char *test_data;
static char *str = NULL;

/* 哈希函数 */
unsigned int mac_hlist_hash(char *str, int hash_size)
{
    unsigned int hash = 0;
    int i;

    for (i = 0; *str; i++) {
        if ((i & 1) == 0) {
            hash ^= ((hash << 7) ^ (*str++) ^ (hash >> 3));
        } else {
            hash ^= (~((hash << 11) ^ (*str++) ^ (hash >> 5)));
        }
    }

    return (hash % hash_size);
}

/* 哈希函数初始化 */
int mac_hash_init(struct hlist_head *hash)
{
    int i;

    for (i = 0; i < MAC_ADDR_LENGTH; i++) {
        INIT_HLIST_HEAD(&hash[i]);
    }
    return 0;
}

/* 添加节点 */
 mac_hlsit_t* mac_hlist_add(char *mac, long int timeout_sec)
{
    unsigned int hash;
    mac_hlsit_t *tmp_mac;

    tmp_mac = (mac_hlsit_t*)kmalloc(sizeof(mac_hlsit_t), GFP_KERNEL);
    if (tmp_mac == NULL ) {
        printk(KERN_EMERG"kmalloc err\n");
        return NULL;
    }
    memset(tmp_mac, 0, sizeof(mac_hlsit_t));
    hash = mac_hlist_hash(mac, MAC_HASH_SIZE);
    hlist_add_head(&tmp_mac->list, &mac_hlist[hash]);
    sprintf(tmp_mac->mac, "%s", mac);
    tmp_mac->timeout_sec = timeout_sec;
    printk("write mac:%s, time: %ld to hash list, num of user: %d\n", mac, timeout_sec, mysysinfo.current_user_num);
    return tmp_mac;
}

/* 删除节点 */
int mac_hlist_adel(mac_hlsit_t *mac_node)
{
    if (mac_node == NULL) {
        printk(KERN_EMERG"input is NULL,nothing to free\n");
        return -1;
    }
    __hlist_del(&mac_node->list);
    kfree(mac_node);
    return 0;
}

/* 打印哈希表 */
int printf_hash(void)
{
    int i;
    struct hlist_node *pos;
    mac_hlsit_t *mac_node;

    printk(KERN_EMERG"********HASH_TABLE_START************\n");
    for (i = 0; i < 256; i++) {
        if(hlist_empty(&mac_hlist[i])) {
            continue;
        }
        hlist_for_each(pos, &mac_hlist[i]) {
            mac_node = hlist_entry(pos, mac_hlsit_t, list);
            printk("mac: %s, time: %ld\n", mac_node->mac, mac_node->timeout_sec);
        }
    }
    printk(KERN_EMERG"********HASH_TABLE_END************\n");
    return 0;
}

unsigned char* get_rand_addr(void)
{
    int i;
    unsigned long n;

    for (i = 0; i < MAC_ADDR_LENGTH; i++) {
        get_random_bytes(&n, 1);
        n = n % 16;
        genMACAddr[i] = HEXCHAR[n];
    }
    return genMACAddr;
}

int send_usrmsg(char *pbuf, uint16_t len)
{
    struct sk_buff *nl_skb;
    struct nlmsghdr *nlh;
    int ret;

    /* 创建sk_buff 空间 */
    nl_skb = nlmsg_new(len, GFP_ATOMIC);
    if(!nl_skb) {
        printk("netlink alloc failure\n");
        return -1;
    }

    /* 设置netlink消息头部 */
    nlh = nlmsg_put(nl_skb, 0, 0, NETLINK_TEST, len, 0);
    if (nlh == NULL) {
        printk("nlmsg_put failaure \n");
        nlmsg_free(nl_skb);
        return -1;
    }
    /* 拷贝数据发送 */
    memcpy(nlmsg_data(nlh), pbuf, len);
    ret = netlink_unicast(nlsk, nl_skb, USER_PORT, MSG_DONTWAIT);

    return ret;
}

/* UBUS_DEL_USER处理函数 */
int ubus_del_user_proc(char *mac)
{
    int i;
    struct hlist_node *pos;
    mac_hlsit_t *mac_node;

    for(i = 0; i < 256; i++) {
        if (hlist_empty(&mac_hlist[i])) {
            continue;
        }
        hlist_for_each(pos, &mac_hlist[i]) {
            mac_node = hlist_entry(pos, mac_hlsit_t, list);
            if (strcmp(mac_node->mac, mac) == 0) {
                printk("ubus delete user mac: %s, time: %ld\n", mac_node->mac, mac_node->timeout_sec);
                mac_hlist_adel(mac_node);
                mysysinfo.current_user_num--;
                return 0;
            }
        }
    }
    printk("have no mac in hash table\n");
    return -1;
}

/* ubus设置超时时间 */
int ubus_set_timeout_sec_proc(char *mac, long int time)
{
    int i;
    struct hlist_node *pos;
    mac_hlsit_t *mac_node;

    for(i = 0; i < 256; i++) {
        if(hlist_empty(&mac_hlist[i])) {
            continue;
        }
        hlist_for_each(pos, &mac_hlist[i]) {
            mac_node = hlist_entry(pos, mac_hlsit_t, list);
            if (strcmp(mac_node->mac, mac) == 0) {
                mac_node->timeout_sec = time;
                printk("ubus set : %s new timeout: %ld success\n", mac_node->mac, mac_node->timeout_sec);
                return 0;
            }
        }
    }
    printk("have no mac in hash table\n");
    return -1;
}

/* 设置最大用户数量 */
void ubus_set_max_user_proc(long int number)
{
    if (number <= 65536 && number >= 0) {
        mysysinfo.max_user_num = number;
        printk("ubus set max user nunmber: %ld success\n",  mysysinfo.max_user_num);
    }
}

/* 内核与用户空间通信消息处理函数 */
int msg_process(char *msg)
{
    char msg_type[50] = {0};
    char mac[13] = {0};
    long int time = 0;
    msg_type_t type;

    if (sscanf(msg, "msg %s %s %ld msgend", msg_type, mac, &time) == 3) {
        if (strcmp(msg_type, "ubus_del_user") == 0) {
            type = UBUS_DEL_USER;
        } else if (strcmp(msg_type, "timeout_sec_rsp") == 0) {
            type = TIMEOUT_SEC_RSP;
        } else if (strcmp(msg_type, "ubus_set_sec") == 0) {
            type = UBUS_SET_TIMEOUT_SEC;
        } else if (strcmp(msg_type, "ubus_set_maxuser") == 0) {
            type = UBUS_SET_MAX_USER;
        } else if (strcmp(msg_type, "ubus_show_user") == 0) {
            type = UBUS_SHOW_USER;
        } else {
            printk("err_msg_type\n");
            return -1;
        }

        switch (type) {
            case TIMEOUT_SEC_RSP:
                printk("receive timeout sec proc**********\n");
                if (mysysinfo.current_user_num < mysysinfo.max_user_num) {
                    mysysinfo.current_user_num++; /* 哈希表中的mac数量+1 */
                    mac_hlist_add(test_data, time);
                }
                break;

            case UBUS_DEL_USER:
                printk("dele user proc**********\n");
                ubus_del_user_proc(mac);
                break;

            case UBUS_SET_TIMEOUT_SEC:
                printk("ubus set timeout second procing********%s \n",mac);
                ubus_set_timeout_sec_proc(mac, time);
                break;

            case UBUS_SET_MAX_USER:
                ubus_set_max_user_proc(time);
                break;

            case UBUS_SHOW_USER:
                printf_hash();
                break;
            
            default:
                break;
        }
    } else {
        printk("msg_process err\n");
        return -1;
    }
    return 0;
}

static void netlink_rcv_msg(struct sk_buff *skb)
{
    struct nlmsghdr *nlh = NULL;
    char *umsg = NULL;

    if (skb->len >= nlmsg_total_size(0)) {
        nlh = nlmsg_hdr(skb);
        umsg = NLMSG_DATA(nlh);
        if (umsg) {
            printk("receive: %s\n", umsg);
            msg_process(umsg);
        }
    }
    return;
}

struct netlink_kernel_cfg cfg = { 
        .input  = netlink_rcv_msg, /* 接收数据回调函数 */
};

int netlink_init(void)
{
    /* create netlink socket */
    nlsk = (struct sock *)netlink_kernel_create(&init_net, NETLINK_TEST, &cfg);
    if(nlsk == NULL) {   
        printk(KERN_EMERG"netlink_kernel_create error !\n");
        return -1; 
    }   
    printk("netlink_init\n");

    return 0;
}

void netlink_exit(void)
{
    if (nlsk) {
        netlink_kernel_release(nlsk); 
        nlsk = NULL;
    }
    printk("netlink_exit!\n");
}

/* 定时器timer，每5秒生成一个随机mac地址 */
void timeout_function(unsigned long arg)
{
    test_data = get_rand_addr();
    send_usrmsg(test_data, strlen(test_data));
    mod_timer(&timer, jiffies + msecs_to_jiffies(5000)); 
}

/* 定时遍历哈希表 */
void timeout_function_2(unsigned long arg)
{
    int i;
    struct hlist_node *pos;
    mac_hlsit_t *mac_node;
    struct timespec ts;
    long int time = 0;

    ts = current_kernel_time();
    time = (long int)ts.tv_sec;
    for(i = 0; i < 256; i++) {
        if(hlist_empty(&mac_hlist[i])) {
            continue;
        }
        hlist_for_each(pos, &mac_hlist[i]) {
            mac_node = hlist_entry(pos, mac_hlsit_t, list);
            if (mac_node->timeout_sec < time) {
                mac_hlist_adel(mac_node);
                mysysinfo.current_user_num--;
                printk("delete mac:%s, time: %ld from hash, current time = %ld, num of user: %d\n", 
                        mac_node->mac, mac_node->timeout_sec, time, mysysinfo.current_user_num);
            }
        }
    }
    mod_timer(&timer2, jiffies + msecs_to_jiffies(5000));
}

void timer_init(void)
{
    init_timer(&timer); 
    timer.function = timeout_function; 
    timer.expires = jiffies + msecs_to_jiffies(1000); 
    timer.data = 1;
    add_timer(&timer); 
}

void timer_init_2(void)
{
    init_timer(&timer2); 
    timer2.function = timeout_function_2; 
    timer2.expires = jiffies + msecs_to_jiffies(5000); 
    timer2.data = 1;
    add_timer(&timer2); 
}

void timer_exit(void)
{
    del_timer(&timer); 
}

void timer_exit_2(void)
{
    del_timer(&timer2); 
}

static int my_proc_show(struct seq_file *m, void *v)
{
    int i;
    struct hlist_node *pos;
    mac_hlsit_t *mac_node;

    for (i = 0; i < 256; i++) {
        if(hlist_empty(&mac_hlist[i])) {
            continue;
        }
        hlist_for_each(pos, &mac_hlist[i]) {
            mac_node = hlist_entry(pos, mac_hlsit_t, list);
            seq_printf(m, "mac:%s, time:%ld\n", mac_node->mac, mac_node->timeout_sec);
        }
    }
    return 0;
}

static int my_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, my_proc_show, NULL);
}

static ssize_t my_proc_write(struct file *file, const char __user *buffer, size_t count, loff_t *f_pos)
{
    char *tmp = kzalloc((count+1), GFP_KERNEL);
    if (!tmp) {
        return -1;
    }
    if (copy_from_user(tmp, buffer, count)) {
        kfree(tmp);
        return -1;
    }
    kfree(str);
    str = tmp;
 
    return count;
}

static struct file_operations my_fops = {
    .owner   = THIS_MODULE,
    .open    = my_proc_open,
    .release = single_release,
    .read    = seq_read,
    .llseek  = seq_lseek,
    .write   = my_proc_write,
};

static int  create_proc_file(void)
{
    struct proc_dir_entry* file = NULL;
 
    file = proc_create(PROC_NODE_ROOT_NAME, 0666, NULL, &my_fops);
    if (!file) {
        printk(KERN_EMERG "create_proc_file Error !!!\n");
        return -1;
    } else {
        printk(KERN_EMERG "create_proc_file Finish.\n");
    }

    return 0;
}

static void remove_proc_file(void)
{
    remove_proc_entry(PROC_NODE_ROOT_NAME, NULL);

    if (str) {
        kfree(str);
    }
    printk(KERN_EMERG"remove_proc_file\n");
}

static int __init demo_module_init(void)
{
    printk(KERN_EMERG"kernel_run\n");
    mysysinfo.current_user_num = 0;
    mysysinfo.max_user_num = MAX_USER_NUM;
    mac_hash_init(mac_hlist);
    netlink_init();
    timer_init();
    timer_init_2();
    create_proc_file();
    return 0;
}

static void __exit demo_module_exit(void)
{
    printk("demo_kernel_ending\n");
    netlink_exit();
    timer_exit();
    timer_exit_2();
    remove_proc_file();
    return;
}

module_init(demo_module_init);
module_exit(demo_module_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("lmj_homework");
