#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <libubox/usock.h>
#include <libubox/uloop.h>

#define SH_PATH    "/tmp/write_file.sh"
#define HELLO_PATH "/tmp/hello.txt"
 
static char *host_addr="127.0.0.1";
static char *server_port="8000";
static char *strhello="Welcome to UBOX world!\n";

struct uloop_fd server_socker_fd;
struct uloop_fd server_accept_fd;
struct uloop_process server_process;

void server_cb(struct uloop_fd *fd, unsigned int events);

int server_touch_file(char path, int path_len)
{
    char cmd[64];
    
    memset(cmd, 0, sizeof(cmd));
    snprintf(cmd, sizeof(cmd), "touch %s", SH_PATH);
    system(cmd);
    printf("server cmd :%s\n", cmd);

    memset(cmd, 0, sizeof(cmd));
    snprintf(cmd, sizeof(cmd), "chmod 777 %s", SH_PATH);
    system(cmd);
    printf("server cmd :%s\n", cmd);

    memset(cmd, 0, sizeof(cmd));
    snprintf(cmd, sizeof(cmd), "echo \"#!/bin/sh\" >> %s ", SH_PATH);
    system(cmd);
    printf("server cmd :%s\n", cmd);

    memset(cmd, 0, sizeof(cmd));
    snprintf(cmd, sizeof(cmd), "echo \" echo \"hello\" > %s\"  >> %s ", HELLO_PATH, SH_PATH);
    system(cmd);
    printf("server cmd :%s\n", cmd);

    return;
}
void server_process_handler(struct uloop_process *c, int ret)
{
    printf("process pid = %d kill !\n", c->pid);
}

/*  client fd event call_back */
void server_read_cb(struct uloop_fd *fd, unsigned int events)
{
    char buf[64];
    int ret;
    pid_t pid;
    
    memset(buf, 0, sizeof(buf));
    ret = read(fd->fd, buf, sizeof(buf));
    
    pid = fork();
    if (pid == 0) {
        /*查看执行脚本是否存在*/
        if (access(SH_PATH, F_OK) != 0) {
            server_touch_file(SH_PATH, sizeof(SH_PATH));
        }
        system(SH_PATH);
        printf("server buf = %s\n", buf);
        raise(SIGKILL);
    } else {

        server_process.pid = pid;
        server_process.cb = server_process_handler;
        uloop_process_add(&server_process); 
    }
    return;
    
}
 
/* server fd event call_back function */
void server_sock_connect_cb(struct uloop_fd *fd, unsigned int events)
{
    server_accept_fd.fd = accept(fd->fd, NULL,  0);
 
    if ( server_accept_fd.fd < 0) {
        perror("server_cb accept");
        return;
    }
    
    server_accept_fd.cb = server_read_cb;
    uloop_fd_add(&server_accept_fd, ULOOP_READ | ULOOP_EDGE_TRIGGER);
}
 
int  main(int argc, char** argv)
{
    int type = USOCK_TCP | USOCK_SERVER | USOCK_NOCLOEXEC | USOCK_IPV4ONLY;
    uloop_init();
    
    server_socker_fd.fd = usock(type, host_addr, server_port);
    if(server_socker_fd.fd < 0) {
        perror("usock");
        exit(-1);
    }
    
    printf("Succeed to create server at %s:%s\n",host_addr, server_port);

    server_socker_fd.cb = server_sock_connect_cb;
    uloop_fd_add(&server_socker_fd, ULOOP_READ | ULOOP_EDGE_TRIGGER); 
 
    uloop_run();

    close(server_socker_fd.fd);
    uloop_done();
    
    return 0;
}
