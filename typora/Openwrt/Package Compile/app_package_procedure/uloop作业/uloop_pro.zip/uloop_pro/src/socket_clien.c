#include <stdio.h>
#include <stdlib.h>
#include <libubox/usock.h>
#include <libubox/uloop.h>
#include <string.h>
#include <sys/time.h>
 
char *host_addr = "127.0.0.1";
char *server_port = "8000";
char *strhello = "Hello!";
struct uloop_timeout clien_time; 
struct uloop_fd clien_fd; 

static void clien_send_timer_function(struct uloop_timeout *timer)
{
    int ret;
    static char count_timer = 0;
    ret = write(clien_fd.fd, strhello, strlen(strhello));
    if (ret < 0)
    {
        uloop_timeout_cancel(timer);
        printf("Cancel send \n");
    }
    
    /*5s与3s交替定时*/
    if (count_timer == 0) {
        count_timer = 1;
        uloop_timeout_set(&clien_time, 5000);
    } else {
        count_timer = 0;
        uloop_timeout_set(&clien_time, 3000);
    }
}

int  main(int argc, char** argv)
{   
    int type = USOCK_TCP | USOCK_NOCLOEXEC | USOCK_IPV4ONLY;
    uloop_init();
    
    clien_fd.fd = usock(type, host_addr, server_port);

    if (clien_fd.fd < 0)
    {
        perror("usock");
        return -1;
    }
    
    clien_time.cb = clien_send_timer_function;
    uloop_timeout_set(&clien_time, 3000); 
    printf("clien start uloop_run() ...\n");
    
    uloop_run();
    
    close(clien_fd.fd);
    uloop_done();
    return 0;
}

